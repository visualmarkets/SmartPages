## v0.0.1.9000

* Adds `lorem(n, m)` to start at position `n` and end at position `m` for subsetting lorem text.



#### v0.0.0.9001

* Removes the magrittr dependency.

## v0.0.0.9000 

* Initial package.
